// ============================================================================
// REALTIME_SERVICE.DART - SERVICIO DE TIEMPO REAL CON SOCKET.IO
// ============================================================================

import 'dart:async';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import '../models/location.dart' as model;
import '../models/driver.dart';

class RealtimeService {
  static final RealtimeService _instance = RealtimeService._internal();
  static RealtimeService get instance => _instance;
  
  RealtimeService._internal();
  
  IO.Socket? _socket;
  bool _isConnected = false;
  Timer? _heartbeatTimer;
  
  // Controladores de streams para eventos
  final StreamController<Map<String, dynamic>> _locationUpdateController = 
      StreamController<Map<String, dynamic>>.broadcast();
  final StreamController<Map<String, dynamic>> _geofenceAlertController = 
      StreamController<Map<String, dynamic>>.broadcast();
  final StreamController<Map<String, dynamic>> _driverStatusController = 
      StreamController<Map<String, dynamic>>.broadcast();
  final StreamController<List<Map<String, dynamic>>> _allDriversController = 
      StreamController<List<Map<String, dynamic>>>.broadcast();
  
  // Streams públicos
  Stream<Map<String, dynamic>> get locationUpdates => _locationUpdateController.stream;
  Stream<Map<String, dynamic>> get geofenceAlerts => _geofenceAlertController.stream;
  Stream<Map<String, dynamic>> get driverStatusUpdates => _driverStatusController.stream;
  Stream<List<Map<String, dynamic>>> get allDriversUpdates => _allDriversController.stream;
  
  // Configuración del servidor
  String _serverUrl = 'http://localhost:3000'; // Cambiar por tu servidor
  String? _currentDriverCode;
  
  bool get isConnected => _isConnected;
  String? get currentDriverCode => _currentDriverCode;
  
  /// Configurar URL del servidor
  void configureServer(String url) {
    _serverUrl = url;
  }
  
  /// Conectar al servidor Socket.IO
  Future<void> connect({String? driverCode}) async {
    if (_isConnected) {
      print('⚠️ Socket ya está conectado');
      return;
    }
    
    try {
      _currentDriverCode = driverCode;
      
      _socket = IO.io(_serverUrl, <String, dynamic>{
        'transports': ['websocket'],
        'autoConnect': false,
        'timeout': 20000,
        'forceNew': true,
      });
      
      _setupSocketListeners();
      
      _socket!.connect();
      
      print('🔄 Conectando a servidor de tiempo real: $_serverUrl');
      
    } catch (e) {
      print('❌ Error conectando socket: $e');
      _isConnected = false;
    }
  }
  
  /// Configurar listeners del socket
  void _setupSocketListeners() {
    if (_socket == null) return;
    
    // Evento de conexión exitosa
    _socket!.on('connect', (data) {
      print('✅ Socket conectado exitosamente');
      _isConnected = true;
      
      // Registrar conductor si está disponible
      if (_currentDriverCode != null) {
        _registerDriver(_currentDriverCode!);
      }
      
      // Iniciar heartbeat
      _startHeartbeat();
    });
    
    // Evento de desconexión
    _socket!.on('disconnect', (data) {
      print('🔌 Socket desconectado: $data');
      _isConnected = false;
      _stopHeartbeat();
    });
    
    // Error de conexión
    _socket!.on('connect_error', (error) {
      print('❌ Error de conexión: $error');
      _isConnected = false;
    });
    
    // Actualizaciones de ubicación de otros conductores
    _socket!.on('location_update', (data) {
      print('📍 Ubicación recibida: $data');
      _locationUpdateController.add(Map<String, dynamic>.from(data));
    });
    
    // Alertas de geocerca
    _socket!.on('geofence_alert', (data) {
      print('🚨 Alerta de geocerca: $data');
      _geofenceAlertController.add(Map<String, dynamic>.from(data));
    });
    
    // Cambios de estado de conductores
    _socket!.on('driver_status_update', (data) {
      print('👤 Estado de conductor actualizado: $data');
      _driverStatusController.add(Map<String, dynamic>.from(data));
    });
    
    // Lista completa de conductores conectados
    _socket!.on('all_drivers_update', (data) {
      print('👥 Conductores actualizados: ${data.length} conductores');
      if (data is List) {
        _allDriversController.add(List<Map<String, dynamic>>.from(
          data.map((item) => Map<String, dynamic>.from(item))
        ));
      }
    });
    
    // Confirmación de registro
    _socket!.on('driver_registered', (data) {
      print('✅ Conductor registrado: $data');
    });
    
    // Respuesta de heartbeat
    _socket!.on('pong', (data) {
      print('💓 Heartbeat recibido');
    });
  }
  
  /// Registrar conductor en el servidor
  void _registerDriver(String driverCode) {
    if (!_isConnected || _socket == null) return;
    
    final driverData = {
      'driverCode': driverCode,
      'timestamp': DateTime.now().toIso8601String(),
      'appVersion': '1.0.0',
    };
    
    _socket!.emit('register_driver', driverData);
    print('📝 Registrando conductor: $driverCode');
  }
  
  /// Enviar actualización de ubicación
  void sendLocationUpdate(model.Location location) {
    if (!_isConnected || _socket == null) {
      print('⚠️ Socket no conectado, no se puede enviar ubicación');
      return;
    }
    
    final locationData = {
      'driverCode': location.driverCode,
      'latitude': location.latitude,
      'longitude': location.longitude,
      'speed': location.speed,
      'timestamp': location.timestamp.toIso8601String(),
      'accuracy': 5.0, // Puedes agregar precisión GPS si está disponible
    };
    
    _socket!.emit('location_update', locationData);
    print('📍 Ubicación enviada: ${location.driverCode} - ${location.latitude}, ${location.longitude}');
  }
  
  /// Enviar alerta de geocerca
  void sendGeofenceAlert(Map<String, dynamic> alertData) {
    if (!_isConnected || _socket == null) {
      print('⚠️ Socket no conectado, no se puede enviar alerta');
      return;
    }
    
    _socket!.emit('geofence_alert', alertData);
    print('🚨 Alerta de geocerca enviada: ${alertData['type']}');
  }
  
  /// Enviar cambio de estado de conductor
  void sendDriverStatusUpdate(String driverCode, String status) {
    if (!_isConnected || _socket == null) {
      print('⚠️ Socket no conectado, no se puede enviar estado');
      return;
    }
    
    final statusData = {
      'driverCode': driverCode,
      'status': status,
      'timestamp': DateTime.now().toIso8601String(),
    };
    
    _socket!.emit('driver_status_update', statusData);
    print('👤 Estado de conductor enviado: $driverCode -> $status');
  }
  
  /// Solicitar lista de todos los conductores conectados
  void requestAllDrivers() {
    if (!_isConnected || _socket == null) {
      print('⚠️ Socket no conectado, no se puede solicitar conductores');
      return;
    }
    
    _socket!.emit('get_all_drivers');
    print('👥 Solicitando lista de conductores');
  }
  
  /// Iniciar heartbeat para mantener conexión
  void _startHeartbeat() {
    _stopHeartbeat(); // Detener heartbeat existente
    
    _heartbeatTimer = Timer.periodic(Duration(seconds: 30), (timer) {
      if (_isConnected && _socket != null) {
        _socket!.emit('ping', {'timestamp': DateTime.now().toIso8601String()});
        print('💓 Enviando heartbeat');
      }
    });
  }
  
  /// Detener heartbeat
  void _stopHeartbeat() {
    _heartbeatTimer?.cancel();
    _heartbeatTimer = null;
  }
  
  /// Unirse a un canal específico (ej: para una flota específica)
  void joinChannel(String channelName) {
    if (!_isConnected || _socket == null) return;
    
    _socket!.emit('join_channel', {'channel': channelName});
    print('🔗 Uniéndose al canal: $channelName');
  }
  
  /// Salir de un canal
  void leaveChannel(String channelName) {
    if (!_isConnected || _socket == null) return;
    
    _socket!.emit('leave_channel', {'channel': channelName});
    print('🚪 Saliendo del canal: $channelName');
  }
  
  /// Desconectar socket
  void disconnect() {
    if (_socket != null) {
      _stopHeartbeat();
      _socket!.disconnect();
      _socket!.dispose();
      _socket = null;
      _isConnected = false;
      _currentDriverCode = null;
      print('🔌 Socket desconectado manualmente');
    }
  }
  
  /// Limpiar recursos
  void dispose() {
    disconnect();
    _locationUpdateController.close();
    _geofenceAlertController.close();
    _driverStatusController.close();
    _allDriversController.close();
  }
  
  /// Reconectar automáticamente
  Future<void> reconnect() async {
    print('🔄 Intentando reconectar...');
    disconnect();
    await Future.delayed(Duration(seconds: 2));
    await connect(driverCode: _currentDriverCode);
  }
  
  /// Verificar estado de la conexión
  bool checkConnection() {
    return _isConnected && _socket != null && _socket!.connected;
  }
}